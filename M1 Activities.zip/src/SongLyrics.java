public class SongLyrics {
    public static void main(String[] args) {
        System.out.println("Back to the basics");
        System.out.println("I can't escape it, no");
        System.out.println("They like they understand me better when I speak it raw");
        System.out.println("I'm thinkin' 'bout how deep it get from diggin' in my thoughts");
        System.out.println("But then again, I already know what come with being a boss");
    }
}
