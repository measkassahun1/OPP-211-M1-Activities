public class Comments {
    public static void main(String[] args) {
        System.out.println("Program comments are non-executing statements.");
        System.out.println("You add to file for documentation, period.");
    }
}

