public class ShowQuoteInfo {
    public static void main(String[] args) {
        System.out.println("\"You betrayed me? No one in the history of torture's been tortured with torture like the torture you'll be tortured with.\"");
        System.out.println("Show: Super Natural");
        System.out.println("Season: 9");
        System.out.println("Episode: 21");
        System.out.println("Character: Crowley");
        System.out.println("Year: 2014 ");
    }
}